var socket = io();
var m = 20;
var n = 20;
var side = 20;

function setup() {
    frameRate(5);
    createCanvas(m * side, n * side);
    background('#33FFFF');
}

function drawMatrix(matrix) {
    background("#acacac");
    for(var y in matrix) {
        for(var x in matrix[y]) {
            if(matrix[y][x] == 0) {
                fill("#acacac");
            }
            else if(matrix[y][x] == 1) {
                fill("green");
            }
            else if(matrix[y][x] == 2) {
                fill("yellow");
            }
            else if(matrix[y][x] == 3) {
                fill("red");
            }
            rect(x * side, y * side, side, side);
        }
    }
    var clientweather = document.getElementById("weatherClient");

    clientweather.innerText = matrix.weatherserver;
}

// socket.on("data", drawMatrix);
// socket.on("exanak", drawCreatures);

// function drawCreatures(data){
//     var clientweather = document.getElementById("weatherClient");

//     clientweather.innerText = data.weatherserver;
// }

socket.on("matrix", drawMatrix);

var matrix = [];
var w = 30;
var h = 30;
var side = 24;
var grassArr = [], xotakerArr = [], gishatichArr = [];

function setup() {
    createCanvas(side * w, side * h);
    background("#acacac");
    frameRate(5);
}