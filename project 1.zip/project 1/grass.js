class Grass extends LivingCreature {
    mul() {
        this.multiply++;
        this.directions = random(this.chooseCell(0));
        if (this.multiply >= 5 && this.directions) {
            var newGrass = new Grass(this.directions[0], this.directions[1], this.index);
            newGrass.parentX = this.x;
            newGrass.parentY = this.y;
            grassArr.push(newGrass);
            matrix[this.directions[1]][this.directions[0]] = this.index;
            this.multiply = 0;
        }
    }
}